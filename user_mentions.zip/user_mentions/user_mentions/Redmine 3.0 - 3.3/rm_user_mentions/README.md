= User Mentions plugin for Redmine
1.0.1
* Added: support CKEditor