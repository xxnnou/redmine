!function($) {
  "use strict"; // jshint ;_;

  var rum_mention = function (element, options) {
    this.$element = $(element);
    this.options = $.extend({}, $.fn.rum_mention.defaults, options);
    this.ck_editor = this.options.ck_editor;
    if (this.ck_editor){
      this.$element = element;
    }
    this.matcher = this.options.matcher || this.matcher;
    this.sorter = this.options.sorter || this.sorter;
    this.highlighter = this.options.highlighter || this.highlighter;
    this.select_formatter = this.options.select_formatter || this.select_formatter;
    this.source = this.options.source;

    this.$popup = $(this.options.popup);
    this.shown = false;
    this.listen();

    this.start_index = 0;
    this.end_index = Infinity;
  };

  rum_mention.prototype = {

    constructor: rum_mention,
    listen: function( ) {
      if(this.ck_editor){
        this.$element.editable().on('click', $.proxy(this.click, this));
        this.$element.editable().on('keypress', $.proxy(this.keypress, this));
        this.$element.editable().on('keyup', $.proxy(this.keyup, this));
        this.$element.editable().on('keydown', $.proxy(this.keydown, this));
      }else{
        this.$element.on('click',    $.proxy(this.click, this)); /* unsupported ck_editor */
        this.$element.on('keypress', $.proxy(this.keypress, this));  /* unsupported ck_editor */
        this.$element.on('keyup',    $.proxy(this.keyup, this));  /* unsupported ck_editor */
      }
      this.$element.on('focus',    $.proxy(this.focus, this)); /* support ck_editor */
      this.$element.on('blur',     $.proxy(this.blur, this));  /* support ck_editor */


      if (this.event_supported('keydown')) {
        this.$element.on('keydown', $.proxy(this.keydown, this)); /* unsupported ck_editor */
      }
      this.$popup
          .on('click', 'li', $.proxy(this.popover_click, this))
          .on('mouseenter', 'li', $.proxy(this.popover_mouseenter, this))
          .on('mouseleave', 'li', $.proxy(this.popover_mouseleave, this))
    },
    click: function( ) { this.hide( ); },
    focus: function( ) { this.focused = true; },
    blur: function( ) {
      this.focused = false;
      if (!this.mouse_in_list && this.shown) { this.hide( ); }
    },
    keydown: function(e) {
      if (!this.shown) { return; }
      switch(this.get_event_key(e)) {
        case 9: // tab
        case 13: // enter
        case 27: // escape
        case 38: // up arrow
        case 40: // down arrow
          this.um_prevent_default(e);
          break;
      }

      this.um_stop_propagation(e);
      if (this.shown && this.check_start_index( )) {
        var value_new = this.get_element_val(this.$element);
        if ((this.before_key_down || this.before_key_down == '') && this.before_key_down.length != value_new.length) {
          this.end_index += value_new.length - this.before_key_down.length;
          this.lookup( );
        }
        this.before_key_down = value_new;
      }
      else { this.before_key_down = undefined; }
    },
    keypress: function(e) {
      if (this.shown && (this.get_event_key(e) == 13 || this.get_event_key(e)  == 9)) { this.um_prevent_default(e); }

      var keyChar = String.fromCharCode(e.which || this.get_event_key(e) );
      if (keyChar == this.options.delimiter && !this.shown) {
        this.start_index = this.selection_start( );
        this.end_index = this.start_index;
        this.lookup( );
        this.before_key_down = this.get_element_val(this.$element);
        return;
      }
      if (!this.event_supported('keydown') && false) {
        if (this.shown && this.check_start_index( )) {
          var value_new = this.get_element_val(this.$element);
          if ((this.before_key_down || this.before_key_down == '') && this.before_key_down.length != value_new.length) {
            this.end_index += value_new.length - this.before_key_down.length;
            this.lookup( );
          }
          this.before_key_down = value_new;
        }
        else { this.before_key_down = undefined; }
      }
    },
    keyup: function(e) {
      this.move(e);
      var value_old = this.before_key_down;
      var value_new = this.get_element_val(this.$element);
      this.before_key_down = value_new;
      if (this.shown && ((!value_old && value_old != '') || (value_old.length == value_new.length && !this.check_query( )) || !this.check_start_index( ))) {
        this.hide( );
        return;
      }
      if (!this.shown) { return; }
      this.end_index += value_new.length - value_old.length;
      if (value_new.length != value_old.length) { this.lookup( ); }
    },
    check_query: function( ) {
      var value = this.get_element_val(this.$element);
      var start = this.selection_start( );
      var end = this.selection_end( );
      return (value && value.length > 0 && start > 0 && end > 0 && start <= end && end <= value.length && start > this.start_index && end <= this.end_index);
    },
    check_start_index: function(value) {
      var value = this.get_element_val(this.$element);
      var start = this.selection_start( );
      return (value && value.length > 0 && start > 0 && start <= value.length && start > this.start_index);
    },

    extract_query: function( ) {
      var value = this.get_element_val(this.$element);
      if (!value || this.start_index == this.end_index) { return ''; }
      return value.substring(this.start_index + 1, this.end_index);
    },


    lookup: function ( ) {
      this.shown = true;
      var items;
      this.query = this.extract_query();
      if (!this.query || (this.query.length < this.options.minLength && this.query != this.options.me)) {
        this.$popup.hide();
        return;
      }

      items = $.isFunction(this.source) ? this.source(this.query, $.proxy(this.process, this)) : this.source;

      return items ? this.process(items) : this;
    },
    process: function(items) {
      var that = this;

      items = $.grep(items, function (item) {
        return that.matcher(item)
      });

      items = this.sorter(items);

      if (!items.length) {
        if (this.shown) { this.$popup.hide( ); }
        return;
      }

      return this.render(items.slice(0, this.options.items)).show( );
    },
    matcher: function (item) { return ~item.toLowerCase().indexOf(this.query.toLowerCase()); },
    sorter: function (items) {
      var beginswith = []
        , caseSensitive = []
        , caseInsensitive = []
        , item;

      while (item = items.shift()) {
        if (!item.toLowerCase().indexOf(this.query.toLowerCase())) beginswith.push(item);
        else if (~item.indexOf(this.query)) caseSensitive.push(item);
        else caseInsensitive.push(item)
      }

      return beginswith.concat(caseSensitive, caseInsensitive)
    },
    highlighter: function (item) {
      var query = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
      return item.replace(new RegExp('(' + query + ')', 'ig'), function ($1, match) {
        return '<strong>' + match + '</strong>'
      });
    },
    render: function(items) {
      var that = this;

      items = $(items).map(function (i, item) {
        if (typeof(item) == 'object') { i = $(that.options.item).attr('data-object', JSON.stringify(item)); }
        else { i = $(that.options.item).attr('data-value', item); }
        i.html(that.highlighter(item));
        return i[0]
      });
      this.$popup.html(items);
      return this;
    },
    select_formatter: function(item) { return this.options.delimiter + item; },


    show: function( ) {
      this.shown = true;
      this.focused = true;

      this.mention_locate( );
      this.$popup.show( );
      return this;
    },
    hide: function( ) {
      this.$popup.hide( );
      this.shown = false;
      this.start_index = 0;
      this.end_index = Infinity;
      this.mouse_in_list = false;
      return this;
    },
    move: function(e) {
      if (!this.shown) { return; }

      switch(this.get_event_key(e) ) {
        case 9: // tab
        case 13: // enter
          this.um_prevent_default(e);
          this.popover_select( );
          break;
        case 27: // escape
          this.um_prevent_default(e);
          this.hide( );
          break;
        case 38: // up arrow
          this.um_prevent_default(e);
          this.popover_prev_item( );
          break;

        case 40: // down arrow
          this.um_prevent_default(e);
          this.popover_next_item( );
          break;
      }

      this.um_stop_propagation(e);
    },

    popover_select: function( ) {
      if(this.ck_editor){
        this.popover_select_ck_editor( );
      }else{
        this.popover_select_default( );
      }
    },

    popover_select_ck_editor: function () {
      var selected = this.$popup.find('.active');
      var val = selected.attr('data-value') || JSON.parse(selected.attr('data-object'));
      var value = this.get_element_val(this.$element);
      var s = value.substring(0, this.start_index);
      var m = this.select_formatter(val);
      this.$element.getSelection().getNative().extentNode.data = s + m + value.substring(this.end_index);
      return this.hide( );
    },

    popover_select_default: function () {
      var selected = this.$popup.find('.active');
      var val = selected.attr('data-value') || JSON.parse(selected.attr('data-object'));
      var value = this.get_element_val(this.$element);
      var s = value.substring(0, this.start_index);
      var m = this.select_formatter(val);
      this.$element.val(s + m + value.substring(this.end_index)).change( );
      this.$element[0].selectionStart = s.length + m.length;
      this.$element[0].selectionEnd = s.length + m.length;
      return this.hide( );
    },


    popover_click: function(e) {
      e.stopPropagation( );
      e.preventDefault( );
      this.popover_select( );
      if(this.ck_editor){
        this.$element.focus( )
      }else{
        this.$element.focus( ).trigger('focus');
      }
      return false;
    },
    popover_mouseenter: function(e) {
      this.mouse_in_list = true;
      this.$popup.find('.active').removeClass('active');
      $(e.currentTarget).addClass('active');
    },
    popover_mouseleave: function(e) {
      this.mouse_in_list = false;
      if (!this.focused && this.shown) { this.hide( ); }
    },
    popover_next_item: function( ) {
      var active = this.$popup.find('.active').removeClass('active');
      var next = active.next( );

      if (!next.length) {
        next = this.$popup.find('li:first');
      }

      next.addClass('active');
    },
    popover_prev_item: function( ) {
      var active = this.$popup.find('.active').removeClass('active');
      var prev = active.prev();

      if (!prev.length) {
        prev = this.$popup.find('li:last');
      }

      prev.addClass('active');
    },

    selection_start: function( ) {
      if(this.ck_editor){
        return this.selection_start_ck_editor();
      }else{
        return this.selection_start_default();
      }
    },
    selection_end: function( ) {
      if(this.ck_editor){
        return this.selection_end_ck_editor();
      }else{
        return this.selection_end_default();
      }
    },

    selection_start_ck_editor: function () {
      return this.$element.getSelection().getNative().focusOffset;
    },

    selection_end_ck_editor: function () {
      return this.$element.getSelection().getNative().focusOffset;
    },

    selection_start_default: function () {
      var input = this.$element.get(0);
      var pos = input.value.length;
      if (typeof(input.selectionStart) != "undefined") {
        pos = input.selectionStart;
      }
      return pos;
    },

    selection_end_default: function () {
      var input = this.$element.get(0);
      var pos = input.value.length;
      if (typeof(input.selectionEnd) != "undefined") {
        pos = input.selectionEnd;
      }
      return pos;
    },

    event_supported: function(eventName) {
      var isSupported = eventName in this.$element;
      if (!isSupported && !this.ck_editor) {
        this.$element.setAttribute(eventName, 'return;');
        isSupported = typeof this.$element[eventName] === 'function'
      }
      return isSupported
    },

    mention_locate: function( ) {
      var offset = this.elem_offset(this.$element);
      var height = this.elem_outerHeight(this.$element);
      if (this.$popup.parent().length == 0) { $(document.body).prepend(this.$popup); }
      this.$popup.css({ left: offset.left, top: offset.top + height });
    },

    get_event_key: function (e) {
      if(this.ck_editor){
        return e.data.getKey()
      }else{
        return e.keyCode
      }
    },

    um_stop_propagation: function (e) {
      if(this.ck_editor){
        return e.data.stopPropagation();
      }else{
        return e.stopPropagation();
      }
    },

    um_prevent_default: function (e) {
      if(this.ck_editor){
        return e.data.preventDefault();
      }else{
        e.preventDefault();
      }
    },

    get_element_val: function (elem) {
      if(this.ck_editor){
        // return this.removeTags(elem.getData());
        // return elem.document.getBody().getText();
        var text = this.$element.getSelection().getNative().extentNode.data;
        if(text === undefined){
          text = '';
        }
        return text
      }
      else{
        return elem.val();
      }
    },

    elem_offset: function (elem) {
      if(this.ck_editor){
        return $(elem.container.$).offset()
      }
      else{
        return elem.offset();
      }
    },

    elem_outerHeight: function (elem) {
      if(this.ck_editor){
        return $(elem.container.$).outerHeight()
      }
      else{
        return elem.outerHeight();
      }
    },

    removeTags: function (html){
      var tagBody = '(?:[^"\'>]|"[^"]*"|\'[^\']*\')*';

      var tagOrComment = new RegExp(
          '<(?:'
          // Comment body.
          + '!--(?:(?:-*[^->])*--+|-?)'
          // Special "raw text" elements whose content should be elided.
          + '|script\\b' + tagBody + '>[\\s\\S]*?</script\\s*'
          + '|style\\b' + tagBody + '>[\\s\\S]*?</style\\s*'
          // Regular name
          + '|/?[a-z]'
          + tagBody
          + ')>',
          'gi');
      var oldHtml;
      do {
        oldHtml = html;
        html = html.replace(tagOrComment, '');
      } while (html !== oldHtml);
      return html.replace(/</g, '&lt;').replace(/&nbsp;/g, ' ');
    }

  };

  var old = $.fn.rum_mention;

  $.fn.rum_mention = function(option) {
    return this.each(function () {
      var $this = $(this)
        , data = $this.data('rum_mention')
        , options = typeof option == 'object' && option;
      if (!data) { $this.data('rum_mention', (data = new rum_mention(this, options))); }
      if (typeof option == 'string') { data[option]( ); }
    })
  };

  $.fn.rum_mention.defaults = {
    ck_editor: false,
    source: [],
    items: 8,
    popup: '<ul class="rum-mention"></ul>',
    item: '<li></li>',
    minLength: 1,
    delimiter: '@',
    me: 'I'
  };

  $.fn.rum_mention.Constructor = rum_mention;

} (window.jQuery);