= User Mentions plugin for Redmine
1.0.4
* Added: support a_common_libs settings
1.0.3
* Fixed: stack level too deep
1.0.2
* Fixed: minor bug
1.0.1
* Added: support CKEditor