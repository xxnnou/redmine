= User Mentions plugin for Redmine

1.0.6
* Fixed: links in emails

1.0.5
* Added: support Rails 5 and Redmine 4
* Dropped: support Rails < 5 and Redmine < 4

1.0.4
* Added: support a_common_libs settings

1.0.3
* Fixed: stack level too deep

1.0.2
* Fixed: minor bug

1.0.1
* Added: support CKEditor